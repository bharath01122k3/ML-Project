from flask import Flask, render_template , request 
import pickle
import joblib


app = Flask(__name__)
#model = pickle.load(open(r'','wb'))
model = pickle.load(open(r"D:\Machine learning Project\Placement_predict.pKl", 'rb'))
#ct=joblib.load('placement')
@app.route('/')
def hello():
    return render_template("index.html")

@app.route('/Y_predict', methods=["POST"])
def Y_predict():
        X_test = [[(yo) for yo in request.form.values()]]
        prediction =model.predict(X_test)
        prediction = prediction[0]
        return render_template("secondpage.html", Y=prediction)


if __name__ == '__main__':
      app.run(debug=True)